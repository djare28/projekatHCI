﻿using Projekat.klase;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for FilterTabeleResursa.xaml
    /// </summary>
    public partial class FilterTabeleResursa : Window
    {
        public static ObservableCollection<ResursModel> ocResursiFilter
        {
            get;
            set;
        }
        public static int Indeks { get; set; }
        public static int IndeksSelektovanog { get; set; }

        public FilterTabeleResursa()
        {
            InitializeComponent();
            this.DataContext = this;
            ocResursiFilter = new ObservableCollection<ResursModel>();
            foreach (var r in TabelaResursa.Resursiii)
            {
                ocResursiFilter.Add(r);
            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            ocResursiFilter.Clear();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (dgrMain.SelectedIndex > -1)
            {
                var p = new DijalogZaDodavanjeResursa();

                ResursModel r;
                IndeksSelektovanog = dgrMain.SelectedIndex;
                r = ocResursiFilter[IndeksSelektovanog];

                r.Izmena = true;

                p.Tekstboks1.IsReadOnly = true;

                p.Oznaka = r.Oznaka;
                p.Naziv = r.Naziv;
                p.Opis = r.Opis;
                p.Tip = r.Tip;

                foreach (var ee in r.ListaEtiketa)
                {
                    foreach (var et in DijalogZaDodavanjeResursa.Etikete)
                    {
                        if (ee.Equals(et.Item))
                        {
                            et.IsChecked = true;
                        }
                    }
                }


                p.ListaEtiketa = r.ListaEtiketa;
                p.Ikonica = r.Ikonica;
                p.MogucnostEksploatacije = r.MogucnostEksploatacije;
                p.StrateskaVaznost = r.StrateskaVaznost;
                p.Obnovljivost = r.Obnovljivost;
                p.FrekvencijaPojavljivanja = r.FrekvencijaPojavljivanja;
                p.Cena = r.Cena;
                p.JedinicaMere = r.JedinicaMere;
                p.Datum = r.Datum;

                p.Show();
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            if (dgrMain.SelectedIndex > -1)
            {
                ResursModel l = (ResursModel)dgrMain.SelectedItem;
                DijalogZaDodavanjeResursa.Resursi.Remove(l.Oznaka);
                ocResursiFilter.RemoveAt(dgrMain.SelectedIndex);
                TabelaResursa.Resursi.Remove(l);
                MainWindow.RR.Obrisi(l);
                MainWindow.OcResursa.Remove(l);

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
