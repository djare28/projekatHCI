﻿using Projekat.klase;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for TabelaTipova.xaml
    /// </summary>
    public partial class TabelaTipova : Window
    {
        public static ObservableCollection<TipModel> tipovi2 { get; set; }
        public static int indeksSelektovanogT { get; set; }

        public TabelaTipova()
        {
            InitializeComponent();
            this.DataContext = this;
            tipovi2 = new ObservableCollection<TipModel>();
            foreach (KeyValuePair<Guid, TipModel> t in MainWindow.RT.getAll())
            {
                tipovi2.Add(t.Value);
            }
        }

        private void izmena(object sender, RoutedEventArgs e)
        {
            var p = new DijalogZaDodavanjeTipa();

            TipModel l = new TipModel();
            if (dgrMain.SelectedIndex > -1)
            {
                indeksSelektovanogT = dgrMain.SelectedIndex;
                l = tipovi2[indeksSelektovanogT];

                l.Izmena = true;

                p.OznakaTipa = l.OznakaTipa;
                p.NazivTipa = l.NazivTipa;
                p.IkonicaTipa = l.IkonicaTipa;
                p.OpisTipa = l.OpisTipa;


                p.ShowDialog();
            }
        }

        private void brisanje(object sender, RoutedEventArgs e)
        {
            TipModel l = (TipModel)dgrMain.SelectedItem;
            l.PostojiResursSaOvimTipom = false;
            foreach (var tip in DijalogZaDodavanjeResursa.Resursi)
            {
                if (tip.Value.Tip.Equals(l.OznakaTipa))
                {
                    l.PostojiResursSaOvimTipom = true;
                }

                if (l.PostojiResursSaOvimTipom == true)
                    break;
            }

            if (l.PostojiResursSaOvimTipom == true)
            {
                var u = new NemogucnostBrisanjaTipa();
                u.ShowDialog();
            }
            else
            {
                if (dgrMain.SelectedIndex > -1)
                {
                    var p = new DijalogZaBrisanjeTipa();
                    p.ShowDialog();
                    if (DijalogZaBrisanjeTipa.potvrda == true)
                    {
                        DijalogZaDodavanjeTipa.tipovi.Remove(l.OznakaTipa);
                        tipovi2.RemoveAt(dgrMain.SelectedIndex);
                        MainWindow.RT.Obrisi(l);
                    }
                }
            }
        }

        private void pretragaa_TextChanged(object sender, TextChangedEventArgs e)
        {
            
                if (pretragaaCB.Text.Equals("Oznaka"))
                {
                    foreach (var x in MainWindow.RT.getAll())
                    {
                        TipModel l = x.Value;
                        if (l.OznakaTipa.Contains(pretragaa.Text))
                        {
                            dgrMain.SelectedItem = l;
                        }
                    }
                }
                else if (pretragaaCB.Text.Equals("Naziv"))
                {
                    foreach (var x in MainWindow.RT.getAll())
                    {
                        TipModel l = x.Value;
                        if (l.NazivTipa.Contains(pretragaa.Text))
                        {
                            dgrMain.SelectedItem = l;
                        }
                    }
                }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            HelpProvider.ShowHelp("TabelaTipovaResursa", this);
        }
    }
}
