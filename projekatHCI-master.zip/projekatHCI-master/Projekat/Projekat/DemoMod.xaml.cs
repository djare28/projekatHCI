﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for DemoMod.xaml
    /// </summary>
    public partial class DemoMod : Window
    {
        public DemoMod()
        {
            InitializeComponent();
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
            MainWindow.povratak = 1;
        }

        private void Grid_KeyDown(object sender, KeyEventArgs e)
        {
            this.Close();
            MainWindow.povratak = 1;
        }
    }
}
