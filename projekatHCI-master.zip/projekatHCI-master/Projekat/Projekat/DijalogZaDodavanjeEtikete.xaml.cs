﻿using Projekat.klase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for DijalogZaDodavanjeEtikete.xaml
    /// </summary>
    public partial class DijalogZaDodavanjeEtikete : Window, INotifyPropertyChanged
    {
        public static Dictionary<string, EtiketaModel> mapaa = new Dictionary<string, EtiketaModel>();

        public event PropertyChangedEventHandler PropertyChanged;

        public DijalogZaDodavanjeEtikete()
        {
            InitializeComponent();
            this.DataContext = this;
            foreach (KeyValuePair<Guid, EtiketaModel> l in MainWindow.RE.getAll())
            {
                if (!mapaa.ContainsKey(l.Value.OznakaEtikete))
                {
                    mapaa.Add(l.Value.OznakaEtikete, l.Value);
                }
            }
        }

        public virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public string _OznakaEtikete;
        public string _OpisEtikete;
        public Color _Boja;


        public string OznakaEtikete
        {
            get
            {
                return _OznakaEtikete;
            }
            set
            {
                if (value != _OznakaEtikete)
                {
                    _OznakaEtikete = value;
                    OnPropertyChanged("OznakaEtikete");
                }
            }
        }

        public string OpisEtikete
        {
            get
            {
                return _OpisEtikete;
            }
            set
            {
                if (value != _OpisEtikete)
                {
                    _OpisEtikete = value;
                    OnPropertyChanged("OpisEtikete");
                }
            }
        }

        public Color Boja
        {
            get
            {
                return _Boja;
            }
            set
            {
                if (value != _Boja)
                {
                    _Boja = value;
                    OnPropertyChanged("Boja");
                }
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Nova_etiketa(object sender, RoutedEventArgs e)
        {
            EtiketaModel et = new EtiketaModel();

            et.OpisEtikete = OpisEtikete;
            et.OznakaEtikete = OznakaEtikete;
            et.Boja = Boja;
            et.BojaS = Boja.ToString();

            if (et.OznakaEtikete != null)
            {
                if (!mapaa.ContainsKey(et.OznakaEtikete))
                {
                    mapaa.Add(et.OznakaEtikete, et);
                    MainWindow.RE.Dodaj(et);
                    if (DijalogZaDodavanjeResursa.Etikete != null)
                    {
                        ListaEtiketa le = new ListaEtiketa(et.OznakaEtikete, false);
                        DijalogZaDodavanjeResursa.Etikete.Add(le);
                    }
                    Close();
                }
                else
                {
                    if (mapaa[et.OznakaEtikete].Izmena == true)
                    {
                        mapaa[et.OznakaEtikete] = et;
                        TabelaEtiketa.etik[TabelaEtiketa.IndeksSelektovanogE] = et;
                        if (DijalogZaDodavanjeResursa.Etikete != null)
                        {
                            ListaEtiketa le = new ListaEtiketa(et.OznakaEtikete, false);
                            DijalogZaDodavanjeResursa.Etikete[TabelaEtiketa.IndeksSelektovanogE] = le;

                            foreach (KeyValuePair<Guid, EtiketaModel> l in MainWindow.RE.getAll())
                            {
                                if (l.Value.OznakaEtikete.Equals(et.OznakaEtikete))
                                {
                                    MainWindow.RE.izmeni(l.Key, et);
                                    break;
                                }
                            }
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Već postoji etiketa sa tom oznakom!");
                    }
                }

            }
            else
            {
                MessageBox.Show("Niste popunili sva obavezna polja!");
            }
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            HelpProvider.ShowHelp("KreiranjeEtikete", this);
        }
    }
}
