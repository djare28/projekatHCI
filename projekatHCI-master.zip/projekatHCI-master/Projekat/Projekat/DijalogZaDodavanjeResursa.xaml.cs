﻿using Microsoft.Win32;
using Projekat.klase;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for DijalogZaDodavanjeResursa.xaml
    /// </summary>
    public partial class DijalogZaDodavanjeResursa : Window, INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        public static Dictionary<string, ResursModel> Resursi { get; set; }
        public static ObservableCollection<string> Tipovi { get; set; }
        public static ObservableCollection<ListaEtiketa> Etikete { get; set; }

        #region NotifyProperties
        public string _oznaka;
        public string _Naziv;
        public string _opis;
        public string _tip;
        public List<string> _ListaEtiketa;
        public string _JedinicaMere;
        public bool _MogucnostEksploatacije;
        public bool _StrateskaVaznost;
        public bool _Obnovljivost;
        public string _cena;
        public string _FrekvencijaPojavljivanja;
        public string _datum;
        public BitmapImage _ikonica;
        public Point _p;
        public string ToolTipResurs;
        public bool _prevucen;
        public int _redniBrojNaCanvasu;
        public Dictionary<string, string> _ListaCekiranihEtiketa;


        public Point p
        {
            get
            {
                return _p;
            }
            set
            {
                if (value != _p)
                {
                    _p = value;
                    OnPropertyChanged("P");
                }
            }
        }

        public List<string> ListaEtiketa
        {
            get
            {
                return _ListaEtiketa;
            }
            set
            {
                if (value != _ListaEtiketa)
                {
                    _ListaEtiketa = value;
                    OnPropertyChanged("ListaEtiketa");
                }
            }
        }

        public Dictionary<string, string> ListaCekiranihEtiketa
        {
            get
            {
                return _ListaCekiranihEtiketa;
            }
            set
            {
                if (value != _ListaCekiranihEtiketa)
                {
                    _ListaCekiranihEtiketa = value;
                    OnPropertyChanged("ListaCekiranihEtiketa");
                }
            }
        }

        public string Oznaka
        {
            get
            {
                return _oznaka;
            }
            set
            {
                if (value != _oznaka)
                {
                    _oznaka = value;
                    OnPropertyChanged("Oznaka");
                }
            }
        }

        public string Naziv
        {
            get
            {
                return _Naziv;
            }
            set
            {
                if (value != _Naziv)
                {
                    _Naziv = value;
                    OnPropertyChanged("Naziv");
                }
            }
        }

        public string Opis
        {
            get
            {
                return _opis;
            }
            set
            {
                if (value != _opis)
                {
                    _opis = value;
                    OnPropertyChanged("Opis");
                }
            }
        }


        public string JedinicaMere
        {
            get
            {
                return _JedinicaMere;
            }
            set
            {
                if (_JedinicaMere == value) return;
                _JedinicaMere = value;
                OnPropertyChanged("JedinicaMere");

            }
        }

        public bool MogucnostEksploatacije
        {
            get
            {
                return _MogucnostEksploatacije;
            }
            set
            {
                if (value != _MogucnostEksploatacije)
                {
                    _MogucnostEksploatacije = value;
                    OnPropertyChanged("MogucnostEksploatacije");
                }
            }
        }

        public bool StrateskaVaznost
        {
            get
            {
                return _StrateskaVaznost;
            }
            set
            {
                if (value != _StrateskaVaznost)
                {
                    _StrateskaVaznost = value;
                    OnPropertyChanged("StrateskaVaznost");
                }
            }
        }

        public bool Obnovljivost
        {
            get
            {
                return _Obnovljivost;
            }
            set
            {
                if (value != _Obnovljivost)
                {
                    _Obnovljivost = value;
                    OnPropertyChanged("Obnovljivost");
                }
            }
        }

        public string Cena
        {
            get
            {
                return _cena;
            }
            set
            {
                if (value != _cena)
                {
                    _cena = value;
                    OnPropertyChanged("Cena");
                }
            }
        }

        public string Tip
        {
            get
            {
                return _tip;
            }
            set
            {
                if (value != _tip)
                {
                    _tip = value;
                    OnPropertyChanged("Tip");
                }
            }
        }

        public string FrekvencijaPojavljivanja
        {
            get
            {
                return _FrekvencijaPojavljivanja;
            }
            set
            {
                if (value != _FrekvencijaPojavljivanja)
                {
                    _FrekvencijaPojavljivanja = value;
                    OnPropertyChanged("FrekvencijaPojavljivanja");
                }
            }
        }

        public string Datum
        {
            get
            {
                return _datum;
            }
            set
            {
                if (value != _datum)
                {
                    _datum = value;
                    OnPropertyChanged("Datum");
                }
            }
        }

        public bool prevucen
        {
            get
            {
                return _prevucen;
            }
            set
            {
                if (value != _prevucen)
                {
                    _prevucen = value;
                    OnPropertyChanged("Prevucen");
                }
            }
        }

        public int RedniBrojNaCanvasu
        {
            get
            {
                return _redniBrojNaCanvasu;
            }
            set
            {
                if (value != _redniBrojNaCanvasu)
                {
                    _redniBrojNaCanvasu = value;
                    OnPropertyChanged("RedniBrojNaCanvasu");
                }
            }
        }

        public BitmapImage Ikonica
        {
            get
            {
                return _ikonica;
            }
            set
            {
                if (value != _ikonica)
                {
                    _ikonica = value;
                    OnPropertyChanged("Ikonica");
                }
            }
        }

        #endregion
        #region PropertyChangedNotifier
        public virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
        #endregion


        public DijalogZaDodavanjeResursa()
        {
            InitializeComponent();
            this.DataContext = this;
            Resursi = new Dictionary<string, ResursModel>();
            Tipovi = new ObservableCollection<string>();
            Etikete = new ObservableCollection<ListaEtiketa>();

            foreach (KeyValuePair<Guid, EtiketaModel> e in MainWindow.RE.getAll())
            {
                ListaEtiketa le = new ListaEtiketa(e.Value.OznakaEtikete, false);
                Etikete.Add(le);
            }
            foreach (KeyValuePair<Guid, TipModel> e in MainWindow.RT.getAll())
            {
                if (!DijalogZaDodavanjeTipa.tipovi.ContainsKey(e.Value.OznakaTipa))
                {
                    DijalogZaDodavanjeTipa.tipovi.Add(e.Value.OpisTipa, e.Value);
                }

                Tipovi.Add(e.Value.OznakaTipa);
            }
            foreach (KeyValuePair<Guid, ResursModel> e in MainWindow.RR.getAll())
            {
                if (!Resursi.ContainsKey(e.Value.Oznaka))
                {
                    Resursi.Add(e.Value.Oznaka, e.Value);
                }

                
            }

        }

        public void Novi_Resurs(object sender, RoutedEventArgs e)
        {
            ResursModel Resurs = new ResursModel();



            Resurs.Oznaka = Oznaka;
            Resurs.Naziv = Naziv;
            Resurs.Opis = Opis;
            Resurs.Tip = Tip;

            Resurs.Ikonica = Ikonica;
            if (Resurs.Ikonica != null)
                Resurs.IkonicaS = Resurs.Ikonica.ToString();

            if (Resurs.Ikonica == null && Resurs.Ikonica == null)
            {
                if (Resurs.Tip != null)
                {
                    if (DijalogZaDodavanjeTipa.tipovi.ContainsKey(Resurs.Tip))
                    {
                        if (DijalogZaDodavanjeTipa.tipovi[Tip].IkonicaTipa != null)
                        {
                            Resurs.Ikonica = DijalogZaDodavanjeTipa.tipovi[Tip].IkonicaTipa;
                            Resurs.IkonicaS = Resurs.Ikonica.ToString();
                        }
                    }
                }
            }

            Resurs.MogucnostEksploatacije = MogucnostEksploatacije;
            Resurs.StrateskaVaznost = StrateskaVaznost;
            Resurs.Obnovljivost = Obnovljivost;

            Resurs.Cena = Cena;
            Resurs.JedinicaMere = JedinicaMere;
            if (FrekvencijaPojavljivanja == "" || FrekvencijaPojavljivanja == null || FrekvencijaPojavljivanja.Contains("nepoznato"))
            {
                Resurs.FrekvencijaPojavljivanja = "(nepoznato)";
            }
            else { Resurs.FrekvencijaPojavljivanja = FrekvencijaPojavljivanja; }
            if (Datum == "" || Datum == null || Datum.Contains("nepoznato"))
            {
                Resurs.Datum = "(nepoznato)";
            }
            else { Resurs.Datum = Datum; }
            //Resurs.RedniBrojNaCanvasu = RedniBrojNaCanvasu;

            Resurs.ToolTipResurs = "- Oznaka: " + Oznaka;
            
            foreach (var et in DijalogZaDodavanjeResursa.Etikete)
            {
                if (et.IsChecked == true)
                    Resurs.ListaEtiketa.Add(et.Item);
            }


            if (Resurs.Oznaka != null && Resurs.Naziv != null && Resurs.Tip != null)
            {
                if (!Resursi.ContainsKey(Resurs.Oznaka))
                {
                    Resursi.Add(Resurs.Oznaka, Resurs);
                    MainWindow.RR.Dodaj(Resurs);
                    MainWindow.OcResursa.Add(Resurs);
                    if (TabelaResursa.Resursi != null)
                    {
                        TabelaResursa.Resursi.Add(Resurs);
                    }
                    Close();
                }
                else
                {
                    if (Resursi[Resurs.Oznaka].Izmena == true)
                    {
                        try
                        {
                            Resurs.P = TabelaResursa.pozicija;
                            for (int i = 0; i < TabelaResursa.Resursi.Count; i++)
                            {
                                if (TabelaResursa.Resursi[i].Oznaka.Equals(TabelaResursa.Resursi[TabelaResursa.indeksSelektovanogL].Oznaka))
                                {
                                    TabelaResursa.Resursi[i] = Resurs;
                                    break;
                                }
                            }
                            foreach (KeyValuePair<Guid, ResursModel> lok in MainWindow.RR.getAll())
                            {
                                if (lok.Value.Oznaka.Equals(Resursi[Resurs.Oznaka].Oznaka))
                                {
                                    MainWindow.RR.Obrisi(Resursi[Resurs.Oznaka]);
                                    MainWindow.RR.Dodaj(Resurs);
                                    break;
                                }
                            }
                            Resursi[Resurs.Oznaka] = Resurs;
                            Close();
                        }
                        catch {
                            Close();
                        }
                        }
                    else
                    {
                        MessageBox.Show("Već postoji resurs sa tom oznakom!");
                    }
                }
            }
            else
            {
                        MessageBox.Show("Niste popunili sva obavezna polja!");
            }
        }

        private void opisi_tip(object sender, RoutedEventArgs e)
        {
            var d = new DijalogZaDodavanjeTipa();
            d.ShowDialog();
        }

        private void unesi_etiketu(object sender, RoutedEventArgs e)
        {
            var d = new DijalogZaDodavanjeEtikete();
            d.ShowDialog();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";

            if (op.ShowDialog() == true)
            {
                Ikonica = new BitmapImage(new Uri(op.FileName));
            }
        }

        private void StartThread()
        {
        }


        private void listBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btpotvrdi1_Copy_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            HelpProvider.ShowHelp("KreiranjeResursa", this);
        }
    }
    
}
