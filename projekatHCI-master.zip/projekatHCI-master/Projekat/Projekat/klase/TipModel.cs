﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace Projekat.klase
{
    [Serializable]
    public class TipModel
    {
        public string OznakaTipa { get; set; }
        public string NazivTipa { get; set; }
        public string OpisTipa { get; set; }
        [NonSerialized]
        public BitmapImage IkonicaTipa;
        public string IkonicaSTipa { get; set; }
        public Guid ID { get; set; }
        public bool Izmena { get; set; }
        public bool PostojiResursSaOvimTipom{ get; set; }

        public TipModel()
        {
            this.PostojiResursSaOvimTipom = false;
            this.Izmena = false;
        }
    }

}
