﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Projekat.klase
{
    class ValidacijaOznake : ValidationRule
    {
        public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo)
        {
            if (Equals(value, ""))
                return new ValidationResult(false, "   Polje ne sme biti prazno.");
            else
            {
                if (Equals(value, " "))
                {
                    return new ValidationResult(false, "   Zabranjen razmak na početku.");
                }
                else
                {
                    return new ValidationResult(true, null);
                }
            }
        }
    }

    class ValidacijaPrihoda : ValidationRule
    {

        public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo)
        {
            string valueS = value.ToString();

            var match = valueS.IndexOfAny("`~!@#$%^&*()_+-=qwertyuio p[]\"\\asdfghjkl;'zxcvbnm,./{}|<>?:QWERTYUIOPASDFGHJKLZXCVBNM".ToCharArray()) != -1;
            if (match)
                return new ValidationResult(false, "      Polje sme da sadrži samo cifre.");
            else
                return new ValidationResult(true, null);
        }
    }

    public class ValidacijaDatuma : ValidationRule
    {

        public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo)
        {
            string valueS = value.ToString();

            DateTime res;

            if(!DateTime.TryParse(valueS, out res))
                return new ValidationResult(false, "      Polje ne sme da sadrži slova.");
            else
                return new ValidationResult(true, null);
        }
    }
}
