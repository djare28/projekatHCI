﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace Projekat.klase
{
    public class RepozitorijumResursa
    {
        private Dictionary<Guid, ResursModel> _r = new Dictionary<Guid, ResursModel>();
        private readonly string _datoteka;

        public RepozitorijumResursa()
        {
            _datoteka = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RepozitorijumResuraTest.podaci");
            UcitajDatoteku();
        }

        public void Dodaj(ResursModel o)
        {
            if (o.ID == Guid.Empty)
                o.ID = Guid.NewGuid();
            if (!_r.ContainsKey(o.ID))
                _r.Add(o.ID, o);
            MemorisiDatoteku();
        }

        public void Obrisi(ResursModel o)
        {
            _r.Remove(o.ID);
            MemorisiDatoteku();
        }

        public ResursModel this[Guid g]
        {
            get
            {
                return _r[g];
            }
            set
            {
                _r[g] = value;
            }
        }

        public void MemorisiDatoteku()
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = null;

            try
            {
                stream = File.Open(_datoteka, FileMode.OpenOrCreate);
                formatter.Serialize(stream, _r);
            }
            catch
            {
                // 
            }
            finally
            {
                if (stream != null)
                    stream.Dispose();
            }
        }

        public void UcitajDatoteku()
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = null;

            if (File.Exists(_datoteka))
            {
                try
                {
                    stream = File.Open(_datoteka, FileMode.Open);
                    _r = (Dictionary<Guid, ResursModel>)formatter.Deserialize(stream);
                    foreach (KeyValuePair<Guid, ResursModel> l in _r)
                    {
                        l.Value.Ikonica = new BitmapImage(new Uri(l.Value.IkonicaS));
                    }
                }
                catch
                {
                    // 
                }
                finally
                {
                    if (stream != null)
                        stream.Dispose();
                }

            }
            else
                _r = new Dictionary<Guid, ResursModel>();
        }

        public Dictionary<Guid, ResursModel> getAll()
        {
            return _r;
        }
    }
}
