﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace Projekat.klase
{
    [Serializable]
    public class ListaResursa : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public BitmapImage image;
        public string item;

        public ListaResursa() { }

        public ListaResursa(string item, BitmapImage image)
        {
            this.item = item;
            this.image = image;
        }

        public string Item
        {
            get { return item; }
            set
            {
                item = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Item"));
            }
        }

        public BitmapImage Image
        {
            get { return image; }
            set
            {
                image = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Image"));
            }
        }
    }
}
