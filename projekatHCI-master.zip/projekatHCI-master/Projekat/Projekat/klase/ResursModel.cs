﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Projekat.klase
{
    [Serializable]
    public class ResursModel
    {
        public Guid ID { get; set; }
        public string Oznaka { get; set; }
        public string Naziv { get; set; }
        public string Opis { get; set; }
        public string Tip { get; set; }
        public string Cena { get; set; }
        public bool MogucnostEksploatacije { get; set; }
        public bool StrateskaVaznost { get; set; }
        public bool Obnovljivost { get; set; }
        public string Datum { get; set; }
        public string JedinicaMere { get; set; }
        public string FrekvencijaPojavljivanja { get; set; }
        [NonSerialized]
        public BitmapImage Ikonica;
        public string IkonicaS { get; set; }
        public List<string> ListaEtiketa { get; set; }
        public string ToolTipResurs { get; set; }
        public bool Izmena { get; set; }
        public Point P { get; set; }
        public int RedniBrojNaCanvasu { get; set; }
        public bool prevucen = false;
        public Dictionary<string, string> ListaCekiranihEtiketa;

        public ResursModel()
        {
            this.ListaEtiketa = new List<string>();
            this.ListaCekiranihEtiketa = new Dictionary<string, string>();
            this.Izmena = false;
        }


    }
}
