﻿using Projekat.klase;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for TabelaEtiketa.xaml
    /// </summary>
    public partial class TabelaEtiketa : Window
    {
        public static ObservableCollection<EtiketaModel> etik { get; set; }
        public static int IndeksSelektovanogE { get; set; }

        public TabelaEtiketa()
        {
            InitializeComponent();
            this.DataContext = this;
            etik = new ObservableCollection<EtiketaModel>();
            foreach (KeyValuePair<Guid, EtiketaModel> t in MainWindow.RE.getAll())
            {
                etik.Add(t.Value);
            }
        }

        private void izmena(object sender, RoutedEventArgs e)
        {
            var p = new DijalogZaDodavanjeEtikete();

            EtiketaModel l = new EtiketaModel();
            if (dgrMain.SelectedIndex > -1)
            {
                IndeksSelektovanogE = dgrMain.SelectedIndex;
                l = etik[IndeksSelektovanogE];

                l.Izmena = true;

                p.OznakaEtikete = l.OznakaEtikete;
                p.Boja = l.Boja;
                p.OpisEtikete = l.OpisEtikete;


                p.ShowDialog();
            }

        }

        private void brisanje(object sender, RoutedEventArgs e)
        {
            if (dgrMain.SelectedIndex > -1)
            {

                EtiketaModel l = (EtiketaModel)dgrMain.SelectedItem;

                if (l.PostojiResursSaOvomEtiketom == true)
                {
                    var u = new NemogucnostBrisanjaEtikete();
                    u.ShowDialog();
                }
                else
                {
                    var p = new DijalogZaBrisanjeEtikete();
                    p.ShowDialog();
                    if (DijalogZaBrisanjeEtikete.potvrda == true)
                    {
                        foreach (var v in DijalogZaDodavanjeResursa.Resursi)
                        {
                            if (v.Value.ListaEtiketa.Contains(l.OznakaEtikete))
                                v.Value.ListaEtiketa.Remove(l.OznakaEtikete);
                        }
                        MainWindow.RE.Obrisi(etik[dgrMain.SelectedIndex]);
                        DijalogZaDodavanjeEtikete.mapaa.Remove(l.OznakaEtikete);
                        etik.RemoveAt(dgrMain.SelectedIndex);
                    }
                }
            }
        }

        private void tbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            foreach (var x in MainWindow.RE.getAll())
            {
                EtiketaModel l = x.Value;
                if (l.OznakaEtikete.Contains(tbox.Text))
                {
                    dgrMain.SelectedItem = l;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            HelpProvider.ShowHelp("TabelaEtiketa", this);
        }
    }
}
