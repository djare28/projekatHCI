﻿using Projekat.klase;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for TabelaResursa.xaml
    /// </summary>
    public partial class TabelaResursa : Window
    {
        public static Point pozicija;
        public static ObservableCollection<ResursModel> Resursi
        {
            get;
            set;
        }
        public static ObservableCollection<ResursModel> Resursiii
        {
            get;
            set;
        }
        public static int indeksSelektovanogL { get; set; }
        public static string ozn { get; set; }

        public TabelaResursa()
        {
            InitializeComponent();
            this.DataContext = this;
            Resursi = new ObservableCollection<ResursModel>();
            Resursiii = new ObservableCollection<ResursModel>();
            foreach (KeyValuePair<Guid, ResursModel> l in MainWindow.RR.getAll())
            {
                Resursi.Add(l.Value);
            }
        }

        private void brisanje(object sender, RoutedEventArgs e)
        {
            var p = new DijalogZaBrisanjeResursa();
            p.ShowDialog();
            if (DijalogZaBrisanjeResursa.potvrda == true)
            {
                brisi();
            }

        }

        public void brisi()
        {
            if (dgrMain.SelectedIndex > -1)
            {
                ResursModel r = (ResursModel)dgrMain.SelectedItem;

                DijalogZaDodavanjeResursa.Resursi.Remove(r.Oznaka);
                Resursi.RemoveAt(dgrMain.SelectedIndex);
                MainWindow.RR.Obrisi(r);
                MainWindow.OcResursa.Remove(r);

            }
        }

        private void izmena(object sender, RoutedEventArgs e)
        {
            if (dgrMain.SelectedIndex > -1)
            {
                var p = new DijalogZaDodavanjeResursa();

                ResursModel l;
                indeksSelektovanogL = dgrMain.SelectedIndex;
                l = Resursi[indeksSelektovanogL];

                pozicija = l.P;

                l.Izmena = true;
                p.Oznaka = l.Oznaka;
                p.Naziv = l.Naziv;
                p.Opis = l.Opis;
                p.Tip = l.Tip;

                foreach (var ee in l.ListaEtiketa)
                {
                    foreach (var et in DijalogZaDodavanjeResursa.Etikete)
                    {
                        if (ee.Equals(et.Item))
                        {
                            et.IsChecked = true;
                        }
                    }
                }


                p.ListaEtiketa = l.ListaEtiketa;
                p.Ikonica = l.Ikonica;
                p.JedinicaMere = l.JedinicaMere;
                p.MogucnostEksploatacije = l.MogucnostEksploatacije;
                p.StrateskaVaznost = l.StrateskaVaznost;
                p.Obnovljivost = l.Obnovljivost;
                p.Cena = l.Cena;
                p.FrekvencijaPojavljivanja = l.FrekvencijaPojavljivanja;
                p.Datum = l.Datum;

                p.ShowDialog();

                MainWindow.OcResursa.Clear();

                foreach (KeyValuePair<Guid, ResursModel> eee in MainWindow.RR.getAll())
                {
                    if (!MainWindow.OcResursa.Contains(eee.Value))
                    {
                        MainWindow.OcResursa.Add(eee.Value);
                    }
                }
            }
        }


        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (cbi.Text.Equals("Oznaka"))
            {
                foreach (var v in MainWindow.RR.getAll())
                {
                    ResursModel r = v.Value;
                    if (r.Oznaka.Contains(tbox.Text))
                        dgrMain.SelectedItem = r;
                }
            }
            else if (cbi.Text.Equals("Naziv"))
            {
                foreach (var v in MainWindow.RR.getAll())
                {
                    ResursModel r = v.Value;
                    if (r.Naziv.Contains(tbox.Text))
                        dgrMain.SelectedItem = r;
                }
            }
            else if (cbi.Text.Equals("Tip"))
            {
                foreach (var v in MainWindow.RR.getAll())
                {
                    ResursModel r = v.Value;
                    if (r.Tip.Contains(tbox.Text))
                        dgrMain.SelectedItem = r;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void filtriranje(object sender, RoutedEventArgs e)
        {
            foreach (var v in Resursiii.ToList())
            {
                Resursiii.Remove(v);
            }

            if (cboxFilter.Text.Equals("Cena veca od"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    int uneto = Int32.Parse(tboxFilter.Text);

                    foreach (var r in Resursi)
                    {
                        int cena = Int32.Parse(r.Cena);

                        if (cena > uneto)
                        {
                            if (!Resursiii.Contains(r))
                                Resursiii.Add(r);
                            else
                                Resursiii.Remove(r);
                        }
                    }
                    var f = new FilterTabeleResursa();
                    f.ShowDialog();
                }
            }

            else if (cboxFilter.Text.Equals("Cena manja od"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    int uneto = Int32.Parse(tboxFilter.Text);

                    foreach (var r in Resursi)
                    {
                        int cena = Int32.Parse(r.Cena);

                        if (cena < uneto)
                        {
                            if (!Resursiii.Contains(r))
                                Resursiii.Add(r);
                            else
                                Resursiii.Remove(r);
                        }
                    }
                    var f = new FilterTabeleResursa();
                    f.ShowDialog();
                }
            }

            else if (cboxFilter.Text.Equals("Tip"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    foreach (var r in Resursi)
                    {
                        if (tboxFilter.Text.Equals(r.Tip))
                        {
                            if (!Resursiii.Contains(r))
                                Resursiii.Add(r);
                            else
                                Resursiii.Remove(r);
                        }
                    }
                    var f = new FilterTabeleResursa();
                    f.ShowDialog();

                }
            }

            else if (cboxFilter.Text.Equals("Obnovljivost (da/ne)"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    if (tboxFilter.Text.Equals("Da") || tboxFilter.Text.Equals("da") || tboxFilter.Text.Equals("DA"))
                    {
                        foreach (var r in Resursi)
                        {
                            if (r.Obnovljivost)
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (tboxFilter.Text.Equals("Ne") || tboxFilter.Text.Equals("ne") || tboxFilter.Text.Equals("NE"))
                    {
                        foreach (var r in Resursi)
                        {
                            if (!r.Obnovljivost)
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }
                }
            }

            else if (cboxFilter.Text.Equals("Strateška važnost (da/ne)"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    if (tboxFilter.Text.Equals("Da") || tboxFilter.Text.Equals("da") || tboxFilter.Text.Equals("DA"))
                    {
                        foreach (var r in Resursi)
                        {
                            if (r.StrateskaVaznost)
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (tboxFilter.Text.Equals("Ne") || tboxFilter.Text.Equals("ne") || tboxFilter.Text.Equals("NE"))
                    {
                        foreach (var r in Resursi)
                        {
                            if (!r.StrateskaVaznost)
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }
                }
            }

            else if (cboxFilter.Text.Equals("Mogućnost eksploatacije (da/ne)"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    if (tboxFilter.Text.Equals("Da") || tboxFilter.Text.Equals("da") || tboxFilter.Text.Equals("DA"))
                    {
                        foreach (var r in Resursi)
                        {
                            if (r.MogucnostEksploatacije)
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (tboxFilter.Text.Equals("Ne") || tboxFilter.Text.Equals("ne") || tboxFilter.Text.Equals("NE"))
                    {
                        foreach (var r in Resursi)
                        {
                            if (!r.MogucnostEksploatacije)
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }
                }
            }

            else if (cboxFilter.Text.Equals("Jedinica mere"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    string uneto = tboxFilter.Text;

                    if (uneto.Equals("Merica") || uneto.Equals("merica") || uneto.Equals("MERICA"))
                    {

                        foreach (var r in Resursi)
                        {
                            if (r.JedinicaMere.Equals("Merica"))
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (uneto.Equals("Barel") || uneto.Equals("barel") || uneto.Equals("BAREL"))
                    {

                        foreach (var r in Resursi)
                        {
                            if (r.JedinicaMere.Equals("Barel"))
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (uneto.Equals("Tona") || uneto.Equals("tona") || uneto.Equals("TONA"))
                    {

                        foreach (var r in Resursi)
                        {
                            if (r.JedinicaMere.Equals("Tona"))
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (uneto.Equals("Kilogram") || uneto.Equals("kilogram") || uneto.Equals("KILOGRAM"))
                    {

                        foreach (var r in Resursi)
                        {
                            if (r.JedinicaMere.Equals("Kilogram"))
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }
                }
            }

            else if (cboxFilter.Text.Equals("Frekvencija pojavljivanja"))
            {
                if (!tboxFilter.Text.Equals(""))
                {
                    string uneto = tboxFilter.Text;

                    if (uneto.Equals("Redak") || uneto.Equals("redak") || uneto.Equals("REDAK"))
                    {

                        foreach (var r in Resursi)
                        {
                            if (r.FrekvencijaPojavljivanja.Equals("Redak"))
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (uneto.Equals("Univerzalan") || uneto.Equals("univerzalan") || uneto.Equals("UNIVERZALAN"))
                    {

                        foreach (var r in Resursi)
                        {
                            if (r.FrekvencijaPojavljivanja.Equals("Univerzalan"))
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }

                    else if (uneto.Equals("Čest") || uneto.Equals("čest") || uneto.Equals("ČEST") || uneto.Equals("Cest") || uneto.Equals("cest") || uneto.Equals("CEST"))
                    {

                        foreach (var r in Resursi)
                        {
                            if (r.FrekvencijaPojavljivanja.Equals("Čest"))
                            {
                                if (!Resursiii.Contains(r))
                                    Resursiii.Add(r);
                                else
                                    Resursiii.Remove(r);
                            }
                        }
                        var f = new FilterTabeleResursa();
                        f.ShowDialog();
                    }
                }
            }
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            HelpProvider.ShowHelp("TabelaResursa", this);
        }
    }
}
