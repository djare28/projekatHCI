﻿using Projekat.klase;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Wpf.Samples;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    //[ComVisibleAttribute(true)]
    public partial class MainWindow : Window
    {
        public static Dictionary<string, ResursModel> Resursi { get; set; }
        public static ResursModel Resurs;

        public static int povratak = 0;

        public static Point pozicija;
        Point startPoint = new Point();

        public static List<ResursModel> testList { get; set; }
        public static List<System.Windows.UIElement> test { get; set; }
        public static List<Point> testPoint { get; set; }

        public static RepozitorijumEtiketa RE { get; set; }
        public static RepozitorijumTipova RT { get; set; }
        public static RepozitorijumResursa RR { get; set; }
        public static ObservableCollection<ResursModel> OcResursa { get; set; }

        public static List<Point> pocetnePozicije { get; set; }

        private Image draggedImage;
        private Point mousePosition;

        public MainWindow()
        {
            InitializeComponent();
            pocetnePozicije = new List<Point>();
            RE = new RepozitorijumEtiketa();
            RT = new RepozitorijumTipova();
            RR = new RepozitorijumResursa();
            testList = new List<ResursModel>();
            test = new List<UIElement>();
            testPoint = new List<Point>();
            OcResursa = new ObservableCollection<ResursModel>();
            this.DataContext = this;
            DijalogZaDodavanjeResursa.Resursi = new Dictionary<string, ResursModel>();
            DijalogZaDodavanjeResursa.Tipovi = new ObservableCollection<string>();
            DijalogZaDodavanjeResursa.Etikete = new ObservableCollection<ListaEtiketa>();
            foreach (KeyValuePair<Guid, EtiketaModel> e in MainWindow.RE.getAll())
            {
                ListaEtiketa le = new ListaEtiketa(e.Value.OznakaEtikete, false);
                DijalogZaDodavanjeResursa.Etikete.Add(le);
            }
            foreach (KeyValuePair<Guid, TipModel> e in MainWindow.RT.getAll())
            {
                if (!DijalogZaDodavanjeTipa.tipovi.ContainsKey(e.Value.OznakaTipa))
                {
                    DijalogZaDodavanjeTipa.tipovi.Add(e.Value.OznakaTipa, e.Value);
                }

                DijalogZaDodavanjeResursa.Tipovi.Add(e.Value.OznakaTipa);
            }

            List<ResursModel> ll = new List<ResursModel>();
            foreach (KeyValuePair<Guid, ResursModel> e in MainWindow.RR.getAll())
            {
                if (!DijalogZaDodavanjeResursa.Resursi.ContainsKey(e.Value.Oznaka))
                {
                    DijalogZaDodavanjeResursa.Resursi.Add(e.Value.Oznaka, e.Value);
                    OcResursa.Add(e.Value);
                }

                Image image = new Image();
                BitmapImage bit = new BitmapImage(new Uri(e.Value.IkonicaS, UriKind.Absolute));
                image.Source = bit;
                image.Width = 25;
                image.Height = 25;

                e.Value.RedniBrojNaCanvasu = canvas.Children.Count;


                Canvas.SetLeft(image, e.Value.P.X - 160);
                Canvas.SetTop(image, e.Value.P.Y - 45);
                canvas.Children.Add(image);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var w = new DijalogZaDodavanjeResursa();
            w.ShowDialog();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var w = new DijalogZaDodavanjeTipa();
            w.ShowDialog();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            var w = new DijalogZaDodavanjeEtikete();
            w.ShowDialog();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            var w = new TabelaTipova();
            w.ShowDialog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var w = new TabelaResursa();
            w.ShowDialog();
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            var w = new TabelaEtiketa();
            w.ShowDialog();
        }


        private void ListView_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            startPoint = e.GetPosition(null);
        }

        private static T FindAncestor<T>(DependencyObject current) where T : DependencyObject
        {
            do
            {
                if (current is T)
                {
                    return (T)current;
                }
                current = VisualTreeHelper.GetParent(current);
            }
            while (current != null);
            return null;
        }

        private void ListView_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(null);
            Vector diff = startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance))
            {
                // Get the dragged ListViewItem
                ListView listView = sender as ListView;

                ListViewItem listViewItem =
                    FindAncestor<ListViewItem>((DependencyObject)e.OriginalSource);

                // Find the data behind the ListViewItem
                if (listViewItem != null)
                {
                    Resurs = (ResursModel)listView.ItemContainerGenerator.
                        ItemFromContainer(listViewItem);
                }

                // Initialize the drag & drop operation

                if (Resurs != null && Resurs.prevucen == false)
                {
                    DataObject dragData = new DataObject("myFormat", Resurs);
                    if (dragData != null && listViewItem != null)
                    {
                        DragDrop.DoDragDrop(listViewItem, dragData, DragDropEffects.Copy);
                    }
                }
            }
        }

        private void ListView_DragEnter(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent("myFormat") || sender == e.Source)
            {
                e.Effects = DragDropEffects.Copy;
            }
        }

        private void DropIkonicu(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("myFormat"))
            {
                Resurs = e.Data.GetData("myFormat") as ResursModel;
                Image image = new Image();
                BitmapImage bit = new BitmapImage(new Uri(Resurs.IkonicaS, UriKind.Absolute));
                image.Source = bit;
                image.Width = 25;
                image.Height = 25;
                image.ToolTip = Resurs.Oznaka;


                Resurs.P = e.GetPosition(this);


                Canvas.SetLeft(image, e.GetPosition(this).X - 160);
                Canvas.SetTop(image, e.GetPosition(this).Y - 45);
                Resurs.RedniBrojNaCanvasu = canvas.Children.Count;
                canvas.Children.Add(image);
                Resurs.prevucen = true;

                MainWindow.OcResursa.Clear();

                foreach (KeyValuePair<Guid, ResursModel> eee in MainWindow.RR.getAll())
                {
                    if (!MainWindow.OcResursa.Contains(eee.Value))
                    {
                        MainWindow.OcResursa.Add(eee.Value);
                    }
                }

                MainWindow.RR.MemorisiDatoteku();
            }
        }

        private void ListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var t = new TabelaResursa();

            ListView listView = sender as ListView;

            ListViewItem listViewItem =
                FindAncestor<ListViewItem>((DependencyObject)e.OriginalSource);

            if (listViewItem != null)
            {
                Resurs = (ResursModel)listView.ItemContainerGenerator.
                    ItemFromContainer(listViewItem);
            }
            t.dgrMain.SelectedItem = Resurs;

            t.Show();
        }

        private void Click_brisanje(object sender, RoutedEventArgs e)
        {
            if (listaResursa.SelectedItems.Count != 0)
            {
                ResursModel r = (ResursModel)listaResursa.SelectedItems[0];

                var p = new DijalogZaBrisanjeResursa();
                p.ShowDialog();
                if (DijalogZaBrisanjeResursa.potvrda == true)
                {
                    DijalogZaDodavanjeResursa.Resursi.Remove(r.Oznaka);

                    MainWindow.RR.Obrisi(r);
                    MainWindow.OcResursa.Remove(r);
                    if (r.prevucen)
                        canvas.Children.RemoveAt(r.RedniBrojNaCanvasu);
                }
            }
        }

        private void CanvasMapa_MouseMove(object sender, MouseEventArgs e)
        {
            if (draggedImage != null)
            {
                var position = e.GetPosition(canvas);
                var offset = position - mousePosition;
                mousePosition = position;
                Canvas.SetLeft(draggedImage, Canvas.GetLeft(draggedImage) + offset.X);
                Canvas.SetTop(draggedImage, Canvas.GetTop(draggedImage) + offset.Y);

            }
        }

        private void CanvasMapa_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (draggedImage != null)
            {
                canvas.ReleaseMouseCapture();
                Panel.SetZIndex(draggedImage, 0);

                draggedImage = null;
                if (Resurs != null)
                {
                    Resurs.P = e.GetPosition(null);
                }
                MainWindow.RR.MemorisiDatoteku();
            }
        }

        private void CanvasMapa_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            var image = e.Source as Image;
            if (image != null && canvas.CaptureMouse())
            {
                mousePosition = e.GetPosition(canvas);
                draggedImage = image;
                Panel.SetZIndex(draggedImage, 1);
            }

        }

        private void click_izmeni(object sender, RoutedEventArgs e)
        {

            if (listaResursa.SelectedItems.Count != 0)
            {
                ResursModel r = (ResursModel)listaResursa.SelectedItems[0];
                r.Izmena = true;
                var p = new DijalogZaDodavanjeResursa();


                pozicija = r.P;

                p.Oznaka = r.Oznaka;
                p.Naziv = r.Naziv;
                p.Opis = r.Opis;
                p.Tip = r.Tip;

                foreach (var ee in r.ListaEtiketa)
                {
                    foreach (var et in DijalogZaDodavanjeResursa.Etikete)
                    {
                        if (ee.Equals(et.Item))
                        {
                            et.IsChecked = true;
                        }
                    }
                }


                p.ListaEtiketa = r.ListaEtiketa;
                p.Ikonica = r.Ikonica;
                p.MogucnostEksploatacije = r.MogucnostEksploatacije;
                p.Obnovljivost = r.Obnovljivost;
                p.StrateskaVaznost = r.StrateskaVaznost;
                p.FrekvencijaPojavljivanja = r.FrekvencijaPojavljivanja;
                p.Cena = r.Cena;
                p.JedinicaMere = r.JedinicaMere;
                p.Datum = r.Datum;
                p.ToolTipResurs = "- Oznaka: " + r.Oznaka;

                p.ShowDialog();

                MainWindow.OcResursa.Clear();

                foreach (KeyValuePair<Guid, ResursModel> eee in MainWindow.RR.getAll())
                {
                    if (!MainWindow.OcResursa.Contains(eee.Value))
                    {
                        MainWindow.OcResursa.Add(eee.Value);
                    }
                }
            }
        }

        private void ukloniSaMape_Click(object sender, EventArgs e)
        {
            if (listaResursa.SelectedItems.Count != 0)
            {
                ResursModel r = (ResursModel)listaResursa.SelectedItems[0];

                Image image = new Image();
                BitmapImage bit = new BitmapImage(new Uri(r.IkonicaS, UriKind.Absolute));
                image.Source = bit;

                if (r.prevucen == true)
                {
                    canvas.Children.RemoveAt(r.RedniBrojNaCanvasu);
                    r.prevucen = false;
                }
                r.RedniBrojNaCanvasu = -1;
                r.prevucen = false;
                MainWindow.RR.MemorisiDatoteku();

                MainWindow.OcResursa.Clear();

                foreach (KeyValuePair<Guid, ResursModel> res in MainWindow.RR.getAll())
                {
                    if (!MainWindow.OcResursa.Contains(res.Value))
                    {
                        MainWindow.OcResursa.Add(res.Value);
                    }
                }

            }
        }

        private void click_prikazi(object sender, RoutedEventArgs e)
        {

            var t = new TabelaResursa();

            ListView listView = sender as ListView;

            ListViewItem listViewItem =
                FindAncestor<ListViewItem>((DependencyObject)e.OriginalSource);

            if (listaResursa.SelectedIndex != -1)
            {
                Resurs = (ResursModel)listaResursa.SelectedItems[0];
                t.dgrMain.SelectedItem = Resurs;
            }

            t.Show();
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            HelpProvider.ShowHelp("PomocPocetnaStranica", this);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            /*foreach (KeyValuePair<Guid, ResursModel> res in MainWindow.RR.getAll())
            {
                if (!res.Value.MogucnostEksploatacije)
                {
                    ResursModel r = res.Value;
                    Image image = new Image();
                    BitmapImage bit = new BitmapImage(new Uri(r.IkonicaS, UriKind.Absolute));
                    image.Source = bit;

                    if (r.prevucen == true)
                    {
                        canvas.Children.RemoveAt(r.RedniBrojNaCanvasu);
                        testList.Add(r);
                        r.prevucen = false;
                    }
                    r.prevucen = false;
                    r.RedniBrojNaCanvasu = -1;

                }
            }*/

            for (int i = 0; i < listaResursa.Items.Count; i++)
            {
                ResursModel r = (ResursModel)listaResursa.Items[i];
                Image image = new Image();
                BitmapImage bit = new BitmapImage(new Uri(r.IkonicaS, UriKind.Absolute));
                image.Source = bit;

                test.Add(image);
                //testPoint.Add(r.P);
                //testList.Add(r);
                //canvas.Children.RemoveAt(r.RedniBrojNaCanvasu);
                //r.prevucen = false;
            }

            for (int i = 0; i < test.Count; i++)
            {
                UIElement e2 = test[i];
                canvas.Children.Remove(e2);
            }

            /* for (int i=0; i<testList.Count; i++)
             {
                 if (testList[i].MogucnostEksploatacije)
                 {
                     Image image = new Image();
                     BitmapImage bit = new BitmapImage(new Uri(testList[i].IkonicaS, UriKind.Absolute));
                     image.Source = bit;
                     image.Width = 25;
                     image.Height = 25;

                     Canvas.SetLeft(image, testList[i].P.X - 160);
                     Canvas.SetTop(image, testList[i].P.Y - 45);
                     testList[i].RedniBrojNaCanvasu = canvas.Children.Count;
                     canvas.Children.Add(image);
                     testList[i].prevucen = true;
                 }
             }*/
        }


        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            foreach (ResursModel testR in testList)
            {
                if (testR.prevucen == false)
                {
                    Image image = new Image();
                    BitmapImage bit = new BitmapImage(new Uri(testR.IkonicaS, UriKind.Absolute));
                    image.Source = bit;
                    image.Width = 25;
                    image.Height = 25;

                    Canvas.SetLeft(image, testR.P.X - 160);
                    Canvas.SetTop(image, testR.P.Y - 45);
                    testR.RedniBrojNaCanvasu = canvas.Children.Count;
                    canvas.Children.Add(image);
                    testR.prevucen = true;
                }
                /*MainWindow.OcResursa.Clear();

                foreach (KeyValuePair<Guid, ResursModel> eee in MainWindow.RR.getAll())
                {
                    if (!MainWindow.OcResursa.Contains(eee.Value))
                    {
                        MainWindow.OcResursa.Add(eee.Value);
                    }
                }

                MainWindow.RR.MemorisiDatoteku();*/
            }
        

            testList.Clear();
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            HelpViewer h = new HelpViewer("PomocPocetnaStranica.html", this);
            h.Show();
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            povratak = 0;
            this.Hide();
            var w = new DemoMod();
            w.ShowDialog();

            do
            {
                if (povratak == 1)
                    this.Show();
            } while (povratak == 0);
        }

        private void DodR_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void DodR_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var d = new DijalogZaDodavanjeResursa();
            d.ShowDialog();
        }

        ////////////////

        private void DodT_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void DodT_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var d = new DijalogZaDodavanjeTipa();
            d.ShowDialog();
        }

        ////////////////

        private void DodE_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void DodE_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var d = new DijalogZaDodavanjeEtikete();
            d.ShowDialog();
        }

        ////////////////

        private void TabR_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void TabR_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var t = new TabelaResursa();
            t.ShowDialog();
        }

        ////////////////

        private void TabT_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void TabT_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var t = new TabelaTipova();
            t.ShowDialog();
        }

        ////////////////

        private void TabE_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void TabE_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var t = new TabelaEtiketa();
            t.ShowDialog();
        }

        public bool provera(Point pTest) {

            pocetnePozicije.Clear();

            for (int i = 0; i < listaResursa.Items.Count; i++)
            {
                ResursModel rm = (ResursModel)listaResursa.Items[i];
                Point pp = rm.P;

                pocetnePozicije.Add(pp);
            }

            for (int i = 0; i < pocetnePozicije.Count; i++)
            {
                for (int j = 0; j < 25; j++)
                {
                    if (pocetnePozicije[i].X == pTest.X + j)
                    {
                        if (pocetnePozicije[i].Y == pTest.Y + j)
                        {
                            return false;
                        }
                    }
                }
            }

            return true;
        }
    }

}
